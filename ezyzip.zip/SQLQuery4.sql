SELECT * FROM employees,departments
SELECT hire_date,first_name,last_name FROM employees
SELECT first_name,last_name,job_id FROM employees
SELECT hire_date,first_name,last_name,phone_number FROM employees
